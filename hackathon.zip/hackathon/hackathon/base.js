// Logout functionality
document.querySelectorAll('#logoutBtn').forEach(btn => {
  btn.addEventListener('click', () => {
    // Clear user session data
    localStorage.removeItem('studentClass');
    localStorage.removeItem('studentSubject');
    localStorage.removeItem('teacherClass');
    localStorage.removeItem('teacherSubject');
    
    // Redirect to login
    window.location.href = 'login.html';
  });
});

// Theme toggle functionality
function initThemeToggle() {
  const themeToggle = document.createElement('button');
  themeToggle.id = 'themeToggle';
  themeToggle.innerHTML = '🌓';
  themeToggle.title = 'Toggle dark/light mode';
  themeToggle.style.position = 'fixed';
  themeToggle.style.bottom = '1rem';
  themeToggle.style.right = '1rem';
  themeToggle.style.zIndex = '1000';
  themeToggle.style.background = 'var(--primary)';
  themeToggle.style.border = 'none';
  themeToggle.style.borderRadius = '50%';
  themeToggle.style.width = '40px';
  themeToggle.style.height = '40px';
  themeToggle.style.display = 'flex';
  themeToggle.style.alignItems = 'center';
  themeToggle.style.justifyContent = 'center';
  themeToggle.style.cursor = 'pointer';
  themeToggle.style.fontSize = '1.25rem';
  
  document.body.appendChild(themeToggle);
  
  themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    localStorage.setItem('theme', 
      document.body.classList.contains('light-mode') ? 'light' : 'dark');
  });
  
  // Check saved preference
  if (localStorage.getItem('theme') === 'light') {
    document.body.classList.add('light-mode');
  }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  initThemeToggle();
  
  // Add loading animation to all buttons with spinner class
  document.querySelectorAll('button').forEach(btn => {
    if (btn.querySelector('.spinner')) {
      btn.style.position = 'relative';
      
      const spinner = btn.querySelector('.spinner');
      spinner.style.position = 'absolute';
      spinner.style.right = '1rem';
      spinner.style.top = '50%';
      spinner.style.transform = 'translateY(-50%)';
      spinner.style.display = 'none';
      spinner.style.width = '20px';
      spinner.style.height = '20px';
      spinner.style.border = '3px solid rgba(255, 255, 255, 0.3)';
      spinner.style.borderRadius = '50%';
      spinner.style.borderTopColor = 'white';
      spinner.style.animation = 'spin 1s ease-in-out infinite';
      
      if (!document.getElementById('spinnerStyles')) {
        const style = document.createElement('style');
        style.id = 'spinnerStyles';
        style.textContent = `
          @keyframes spin {
            to { transform: translateY(-50%) rotate(360deg); }
          }
        `;
        document.head.appendChild(style);
      }
    }
  });
});

// Helper function to show toast notifications
function showToast(message, type = 'success', duration = 3000) {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  
  // Style the toast
  toast.style.position = 'fixed';
  toast.style.bottom = '1rem';
  toast.style.left = '50%';
  toast.style.transform = 'translateX(-50%)';
  toast.style.padding = '0.75rem 1.5rem';
  toast.style.background = type === 'success' ? 'var(--success)' : 'var(--error)';
  toast.style.color = 'white';
  toast.style.borderRadius = '8px';
  toast.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
  toast.style.zIndex = '1000';
  toast.style.animation = 'fadeIn 0.3s ease-out';
  
  document.body.appendChild(toast);
  
  // Add fadeIn animation
  if (!document.getElementById('toastStyles')) {
    const style = document.createElement('style');
    style.id = 'toastStyles';
    style.textContent = `
      @keyframes fadeIn {
        from { opacity: 0; transform: translateX(-50%) translateY(20px); }
        to { opacity: 1; transform: translateX(-50%) translateY(0); }
      }
      
      .toast {
        animation: fadeIn 0.3s ease-out;
      }
    `;
    document.head.appendChild(style);
  }
  
  // Remove toast after duration
  setTimeout(() => {
    toast.style.animation = 'fadeOut 0.3s ease-out';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// Make helper function available globally
window.showToast = showToast;