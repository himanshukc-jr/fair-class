document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('loginForm');
  const loginBtn = document.querySelector('.login-btn');
  const spinner = loginBtn.querySelector('.spinner');
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const userType = document.querySelector('input[name="userType"]:checked').value;
  
  // Validate inputs
  if (!username) {
    showError("Please enter your email address");
    document.getElementById('username').focus();
    return;
  }
  
  // Show loading state
  loginBtn.disabled = true;
  loginBtn.querySelector('.btn-text').textContent = 'Authenticating...';
  spinner.style.display = 'block';
  
  try {
    // Simulate API call with 1.5s delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Accept any non-empty password (as per requirements)
    if (password.length > 0) {
      // Store user type in localStorage
      localStorage.setItem('userType', userType);
      
      // Redirect based on user type
      if (userType === 'student') {
        window.location.href = 'student_select.html';
      } else if (userType === 'teacher') {
        window.location.href = 'teacher_select.html';
      } else if (userType === 'moderator') {
        window.location.href = 'moderator.html';
      }
    }
  } catch (error) {
    showError(error.message || "Login failed. Please try again.");
  } finally {
    // Reset loading state
    loginBtn.disabled = false;
    loginBtn.querySelector('.btn-text').textContent = 'Continue Learning';
    spinner.style.display = 'none';
  }
});

  function showError(message) {
    const errorEl = document.createElement('div');
    errorEl.className = 'error-message';
    errorEl.textContent = message;
    
    // Remove any existing error messages
    const existingError = document.querySelector('.error-message');
    if (existingError) {
      existingError.remove();
    }
    
    // Insert error message
    loginForm.insertBefore(errorEl, loginForm.firstChild);
    
    // Style the error message
    errorEl.style.color = '#EF4444';
    errorEl.style.marginBottom = '1rem';
    errorEl.style.padding = '0.75rem 1rem';
    errorEl.style.background = 'rgba(239, 68, 68, 0.1)';
    errorEl.style.borderLeft = '3px solid #EF4444';
    errorEl.style.borderRadius = '8px';
    errorEl.style.animation = 'fadeIn 0.3s ease-out';
    
    // Hide error after 5 seconds
    setTimeout(() => {
      errorEl.style.opacity = '0';
      setTimeout(() => errorEl.remove(), 300);
    }, 5000);
  }

  // Add floating label functionality
  const floatingInputs = document.querySelectorAll('.floating input');
  floatingInputs.forEach(input => {
    input.addEventListener('focus', () => {
      const label = input.nextElementSibling;
      label.style.top = '-0.6rem';
      label.style.left = '3rem';
      label.style.fontSize = '0.75rem';
      label.style.background = 'linear-gradient(135deg, #1F2937, #111827)';
      label.style.padding = '0 0.5rem';
      label.style.color = '#818CF8';
    });
    
    input.addEventListener('blur', () => {
      if (!input.value) {
        const label = input.nextElementSibling;
        label.style.top = '1rem';
        label.style.left = '3rem';
        label.style.fontSize = '1rem';
        label.style.background = 'transparent';
        label.style.padding = '0';
        label.style.color = '#6B7280';
      }
    });
  });
});
