const allQuizData = {
  "8_english": [
    { 
      question: "What is the noun in the sentence: 'The quick brown fox jumps over the lazy dog'?",
      options: ["quick", "fox", "jumps", "lazy"],
      answer: 1,
      hint: "A noun is a person, place, thing, or idea.",
      explanation: "The correct answer is 'fox' because it's the name of an animal (a thing)."
    },
    { 
      question: "Which of these is a proper noun?",
      options: ["city", "apple", "John", "car"],
      answer: 2,
      hint: "Proper nouns name specific people, places, or things and are capitalized.",
      explanation: "The correct answer is 'John' because it's the name of a specific person."
    }
  ],
  "10_science": [
    { 
      question: "At what temperature does water freeze at sea level?",
      options: ["0°C", "100°C", "-10°C", "50°C"],
      answer: 0,
      hint: "Think about the temperature scale where water changes state.",
      explanation: "Water freezes at 0°C (32°F) at standard atmospheric pressure."
    },
    { 
      question: "What is the chemical formula for water?",
      options: ["CO2", "H2O2", "NaCl", "H2O"],
      answer: 3,
      hint: "This molecule contains hydrogen and oxygen.",
      explanation: "The chemical formula for water is H₂O, meaning two hydrogen atoms bonded to one oxygen atom."
    }
  ]
};

let quizData = [];
let currentQuestion = 0;
let score = 0;
let selectedOption = null;
let timer;
let timeLeft = 120; // 2 minutes per question

const questionEl = document.getElementById('quiz-question');
const optionsEl = document.getElementById('quiz-options');
const nextBtn = document.getElementById('nextBtn');
const skipBtn = document.getElementById('skipBtn');
const hintBtn = document.getElementById('hintBtn');
const hintTextEl = document.getElementById('hintText');
const hintEl = document.getElementById('quiz-hint');
const resultEl = document.getElementById('quiz-result');
const explanationEl = document.getElementById('quiz-explanation');
const feedbackEl = document.getElementById('quiz-feedback');
const progressFill = document.getElementById('progressFill');
const progressText = document.getElementById('progressText');
const timeLeftEl = document.getElementById('timeLeft');
const quizTimer = document.getElementById('quizTimer');
const quizScore = document.getElementById('quizScore');

window.addEventListener('DOMContentLoaded', () => {
  const studentClass = localStorage.getItem('studentClass');
  const studentSubject = localStorage.getItem('studentSubject');

  if (!studentClass || !studentSubject) {
    alert('Please select class and subject first.');
    window.location.href = 'student_select.html';
    return;
  }

  const key = `${studentClass}_${studentSubject}`;
  quizData = allQuizData[key] || [];

  if (quizData.length === 0) {
    questionEl.textContent = 'No quiz available for this subject and class.';
    nextBtn.style.display = 'none';
    return;
  }

  loadQuestion();
});

function loadQuestion() {
  // Reset state
  selectedOption = null;
  nextBtn.disabled = true;
  skipBtn.disabled = false;
  hintBtn.disabled = false;
  feedbackEl.classList.add('hidden');
  hintEl.classList.add('hidden');
  
  // Update progress
  progressFill.style.width = `${(currentQuestion / quizData.length) * 100}%`;
  progressText.textContent = `${currentQuestion + 1}/${quizData.length}`;
  quizScore.innerHTML = `Score: <strong>${score}</strong>`;
  
  // Start timer
  startTimer();
  
  const q = quizData[currentQuestion];
  questionEl.textContent = q.question;
  optionsEl.innerHTML = '';
  
  // Create options
  q.options.forEach((option, idx) => {
    const li = document.createElement('li');
    li.textContent = option;
    li.addEventListener('click', () => selectOption(idx));
    optionsEl.appendChild(li);
  });
}

function selectOption(idx) {
  if (selectedOption !== null) return;
  
  selectedOption = idx;
  highlightSelection(idx);
  nextBtn.disabled = false;
  checkAnswer();
}

function highlightSelection(idx) {
  Array.from(optionsEl.children).forEach((li, i) => {
    li.classList.toggle('selected', i === idx);
  });
}

function checkAnswer() {
  const q = quizData[currentQuestion];
  const isCorrect = selectedOption === q.answer;
  
  // Show feedback
  feedbackEl.classList.remove('hidden');
  
  if (isCorrect) {
    score++;
    resultEl.textContent = 'Correct! 🎉';
    resultEl.style.color = 'var(--success)';
  } else {
    resultEl.textContent = 'Incorrect 😕';
    resultEl.style.color = 'var(--error)';
  }
  
  // Show explanation
  explanationEl.textContent = q.explanation;
  
  // Update score display
  quizScore.innerHTML = `Score: <strong>${score}</strong>`;
  
  // Highlight correct answer
  Array.from(optionsEl.children).forEach((li, i) => {
    if (i === q.answer) {
      li.classList.add('correct');
    } else if (i === selectedOption && !isCorrect) {
      li.classList.add('incorrect');
    }
    li.style.cursor = 'default';
  });
  
  // Stop timer
  clearInterval(timer);
}

function startTimer() {
  timeLeft = 120; // Reset to 2 minutes
  updateTimerDisplay();
  
  timer = setInterval(() => {
    timeLeft--;
    updateTimerDisplay();
    
    if (timeLeft <= 0) {
      clearInterval(timer);
      timeUp();
    }
  }, 1000);
}

function updateTimerDisplay() {
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  timeLeftEl.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  
  // Change color when time is running low
  if (timeLeft <= 30) {
    quizTimer.style.color = 'var(--error)';
  } else {
    quizTimer.style.color = 'inherit';
  }
}

function timeUp() {
  feedbackEl.classList.remove('hidden');
  resultEl.textContent = 'Time is up! ⏱️';
  resultEl.style.color = 'var(--error)';
  explanationEl.textContent = quizData[currentQuestion].explanation;
  
  // Highlight correct answer
  const correctIdx = quizData[currentQuestion].answer;
  optionsEl.children[correctIdx].classList.add('correct');
  
  // Disable all options
  Array.from(optionsEl.children).forEach(li => {
    li.style.cursor = 'default';
  });
  
  nextBtn.disabled = false;
}

hintBtn.addEventListener('click', () => {
  hintTextEl.textContent = quizData[currentQuestion].hint;
  hintEl.classList.remove('hidden');
  hintBtn.disabled = true;
});

skipBtn.addEventListener('click', () => {
  clearInterval(timer);
  currentQuestion++;
  
  if (currentQuestion < quizData.length) {
    loadQuestion();
  } else {
    showResult();
  }
});

nextBtn.addEventListener('click', () => {
  clearInterval(timer);
  currentQuestion++;
  
  if (currentQuestion < quizData.length) {
    loadQuestion();
  } else {
    showResult();
  }
});

function showResult() {
  questionEl.textContent = 'Quiz Completed!';
  optionsEl.innerHTML = '';
  nextBtn.style.display = 'none';
  skipBtn.style.display = 'none';
  hintBtn.style.display = 'none';
  quizTimer.style.display = 'none';
  
  const percentage = Math.round((score / quizData.length) * 100);
  let message;
  
  if (percentage >= 80) {
    message = `Excellent! You scored ${score}/${quizData.length} (${percentage}%)`;
  } else if (percentage >= 50) {
    message = `Good job! You scored ${score}/${quizData.length} (${percentage}%)`;
  } else {
    message = `Keep practicing! You scored ${score}/${quizData.length} (${percentage}%)`;
  }
  
  resultEl.textContent = message;
  feedbackEl.classList.remove('hidden');
  explanationEl.textContent = 'Review your notes and try again to improve your score!';
  
  // Show confetti for good scores
  if (percentage >= 70) {
    showConfetti();
  }
}

function showConfetti() {
  import('https://cdn.skypack.dev/canvas-confetti').then(confetti => {
    confetti.default({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });
  });
}