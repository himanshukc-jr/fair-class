document.getElementById('viewNotes').addEventListener('click', () => {
  window.location.href = 'notes.html';
});

document.getElementById('takeQuiz').addEventListener('click', () => {
  window.location.href = 'quiz.html';
});

document.getElementById('downloadAssignments').addEventListener('click', () => {
  window.location.href = 'assignments.html';
});

// Show selected class and subject
window.addEventListener('DOMContentLoaded', () => {
  const studentClass = localStorage.getItem('studentClass');
  const studentSubject = localStorage.getItem('studentSubject');

  if (!studentClass || !studentSubject) {
    alert('Please select class and subject first.');
    window.location.href = 'student_select.html';
    return;
  }

  const header = document.querySelector('header h1');
  header.textContent += ` - Class ${studentClass}, Subject: ${capitalize(studentSubject.replace('_', ' '))}`;
});

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

document.addEventListener('DOMContentLoaded', () => {
  const userRole = localStorage.getItem('userType');
  if (userRole !== 'student') {
    alert('Student access required');
    window.location.href = 'login.html';
  }
  
  // Rest of existing student.js code...
});