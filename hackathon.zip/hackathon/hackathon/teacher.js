// Sample data for uploaded materials
const materialsData = [
  {
    id: 1,
    name: "Chapter 3 - Photosynthesis",
    type: "note",
    class: "8",
    subject: "science",
    date: "2023-05-15",
    size: "2.4 MB",
    downloads: 24
  },
  {
    id: 2,
    name: "Assignment 1 - Algebra",
    type: "assignment",
    class: "10",
    subject: "c_math",
    date: "2023-05-10",
    size: "1.1 MB",
    downloads: 32
  }
];

// Initialize when DOM is loaded
window.addEventListener('DOMContentLoaded', () => {
  const teacherClass = localStorage.getItem('teacherClass');
  const teacherSubject = localStorage.getItem('teacherSubject');

  if (!teacherClass || !teacherSubject) {
    alert('Please select class and subject first.');
    window.location.href = 'teacher_select.html';
    return;
  }

  // Update heading
  updateHeading(teacherClass, teacherSubject);

  // Load materials for the selected class and subject
  loadMaterials(teacherClass, teacherSubject);

  // Setup tab switching
  setupTabSwitching();

  // Setup drag and drop
  setupDragAndDrop();
});

function updateHeading(teacherClass, teacherSubject) {
  const heading = document.getElementById('heading');
  if (heading) {
    heading.textContent = `Class ${teacherClass} - ${capitalize(teacherSubject.replace('_', ' '))}`;
  }
}

function capitalize(str) {
  return str ? str.charAt(0).toUpperCase() + str.slice(1) : '';
}

function setupTabSwitching() {
  const uploadTabBtn = document.getElementById('uploadTabBtn');
  const manageTabBtn = document.getElementById('manageTabBtn');

  if (uploadTabBtn && manageTabBtn) {
    uploadTabBtn.addEventListener('click', () => switchTab('uploadTab'));
    manageTabBtn.addEventListener('click', () => switchTab('manageTab'));
  }
}

function switchTab(tabId) {
  // Hide all tabs
  document.querySelectorAll('.tab-content').forEach(tab => {
    tab.classList.remove('active');
  });

  // Deactivate all tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.remove('active');
  });

  // Show selected tab
  const tab = document.getElementById(tabId);
  if (tab) {
    tab.classList.add('active');
  }

  // Activate selected button
  const tabBtn = document.getElementById(`${tabId}Btn`);
  if (tabBtn) {
    tabBtn.classList.add('active');
  }
}

function loadMaterials(classLevel, subject) {
  const materialsList = document.getElementById('materialsList');
  if (!materialsList) return;

  // Filter materials for current class and subject
  const filteredMaterials = materialsData.filter(material => 
    material.class === classLevel && material.subject === subject
  );

  if (filteredMaterials.length === 0) {
    materialsList.innerHTML = `
      <div class="empty-state">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
          <polyline points="14 2 14 8 20 8"></polyline>
          <line x1="16" y1="13" x2="8" y2="13"></line>
          <line x1="16" y1="17" x2="8" y2="17"></line>
          <polyline points="10 9 9 9 8 9"></polyline>
        </svg>
        <h3>No materials uploaded yet</h3>
        <p>Upload your first material to get started</p>
      </div>
    `;
    return;
  }

  // Generate materials list
  materialsList.innerHTML = filteredMaterials.map(material => `
    <div class="material-item">
      <div class="material-icon">
        ${getFileIcon(material.type)}
      </div>
      <div class="material-info">
        <h4>${material.name}</h4>
        <div class="material-meta">
          <span>Uploaded: ${material.date}</span>
          <span>Size: ${material.size}</span>
          <span>Downloads: ${material.downloads}</span>
        </div>
      </div>
      <div class="material-actions">
        <button class="download-btn" data-id="${material.id}">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="7 10 12 15 17 10"></polyline>
            <line x1="12" y1="15" x2="12" y2="3"></line>
          </svg>
        </button>
        <button class="delete-btn" data-id="${material.id}">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <polyline points="3 6 5 6 21 6"></polyline>
            <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
          </svg>
        </button>
      </div>
    </div>
  `).join('');

  // Add event listeners to action buttons
  document.querySelectorAll('.download-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const materialId = e.currentTarget.getAttribute('data-id');
      downloadMaterial(materialId);
    });
  });

  document.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const materialId = e.currentTarget.getAttribute('data-id');
      deleteMaterial(materialId);
    });
  });
}

function getFileIcon(type) {
  const icons = {
    note: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
      <polyline points="14 2 14 8 20 8"></polyline>
      <line x1="16" y1="13" x2="8" y2="13"></line>
      <line x1="16" y1="17" x2="8" y2="17"></line>
      <polyline points="10 9 9 9 8 9"></polyline>
    </svg>`,
    assignment: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
      <polyline points="14 2 14 8 20 8"></polyline>
      <line x1="16" y1="13" x2="8" y2="13"></line>
      <line x1="16" y1="17" x2="8" y2="17"></line>
    </svg>`,
    slides: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
      <line x1="9" y1="9" x2="15" y2="9"></line>
      <line x1="9" y1="13" x2="15" y2="13"></line>
      <line x1="9" y1="17" x2="15" y2="17"></line>
    </svg>`,
    other: `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
      <polyline points="13 2 13 9 20 9"></polyline>
    </svg>`
  };
  
  return icons[type] || icons.other;
}

function downloadMaterial(id) {
  const material = materialsData.find(m => m.id == id);
  if (material) {
    showToast(`Preparing download: ${material.name}`, 'info');
    // In a real app, this would initiate a file download
    // Simulate download delay
    setTimeout(() => {
      showToast(`Download started: ${material.name}`, 'success');
      // Update download count
      material.downloads++;
      // Refresh materials list
      const teacherClass = localStorage.getItem('teacherClass');
      const teacherSubject = localStorage.getItem('teacherSubject');
      loadMaterials(teacherClass, teacherSubject);
    }, 1000);
  }
}

function deleteMaterial(id) {
  if (confirm('Are you sure you want to delete this material?')) {
    const index = materialsData.findIndex(m => m.id == id);
    if (index !== -1) {
      materialsData.splice(index, 1);
      const teacherClass = localStorage.getItem('teacherClass');
      const teacherSubject = localStorage.getItem('teacherSubject');
      loadMaterials(teacherClass, teacherSubject);
      showToast('Material deleted successfully', 'success');
    }
  }
}

function setupDragAndDrop() {
  const dropZone = document.getElementById('dropZone');
  const fileInput = document.getElementById('fileInput');
  const filePreview = document.getElementById('filePreview');
  const uploadBtn = document.getElementById('uploadBtn');
  const uploadStatus = document.getElementById('uploadStatus');
  
  if (!dropZone || !fileInput || !filePreview || !uploadBtn || !uploadStatus) {
    console.error('Required elements for drag and drop not found');
    return;
  }
  
  let files = [];
  
  // Handle drag and drop events
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, preventDefaults, false);
  });
  
  function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
  }
  
  ['dragenter', 'dragover'].forEach(eventName => {
    dropZone.addEventListener(eventName, highlight, false);
  });
  
  ['dragleave', 'drop'].forEach(eventName => {
    dropZone.addEventListener(eventName, unhighlight, false);
  });
  
  function highlight() {
    dropZone.classList.add('highlight');
  }
  
  function unhighlight() {
    dropZone.classList.remove('highlight');
  }
  
  dropZone.addEventListener('drop', handleDrop, false);
  
  function handleDrop(e) {
    const dt = e.dataTransfer;
    if (dt.files.length) {
      files = dt.files;
      handleFiles(files);
    }
  }
  
  fileInput.addEventListener('change', function() {
    if (this.files.length) {
      files = this.files;
      handleFiles(files);
    }
  });
  
  function handleFiles(newFiles) {
    filePreview.innerHTML = '';
    
    if (!newFiles || newFiles.length === 0) {
      uploadBtn.disabled = true;
      return;
    }
    
    // Validate file types (example: only allow PDFs)
    const validFiles = Array.from(newFiles).filter(file => 
      file.type === 'application/pdf' || file.name.endsWith('.pdf')
    );
    
    if (validFiles.length !== newFiles.length) {
      showToast('Only PDF files are allowed', 'error');
    }
    
    if (validFiles.length === 0) {
      uploadBtn.disabled = true;
      return;
    }
    
    files = validFiles;
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileItem = document.createElement('div');
      fileItem.className = 'file-preview-item';
      fileItem.innerHTML = `
        <span>${file.name}</span>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      `;
      
      // Add click event to remove file
      fileItem.querySelector('svg').addEventListener('click', () => {
        files = files.filter(f => f.name !== file.name);
        fileItem.remove();
        if (files.length === 0) {
          uploadBtn.disabled = true;
        }
      });
      
      filePreview.appendChild(fileItem);
    }
    
    uploadBtn.disabled = false;
  }
  
  uploadBtn.addEventListener('click', handleUpload);
  
  function handleUpload() {
    if (!files || files.length === 0) {
      showToast('Please select files to upload', 'error');
      return;
    }
    
    const materialType = document.getElementById('materialType');
    const chapterInput = document.getElementById('chapter');
    
    if (!materialType || !chapterInput) {
      showToast('Form elements not found', 'error');
      return;
    }
    
    const chapter = chapterInput.value.trim();
    
    if (!chapter) {
      showToast('Please enter a chapter/title', 'error');
      return;
    }
    
    // Show loading state
    uploadBtn.disabled = true;
    const btnText = uploadBtn.querySelector('.btn-text');
    const spinner = uploadBtn.querySelector('.spinner');
    
    if (btnText) btnText.textContent = 'Uploading...';
    if (spinner) spinner.classList.remove('hidden');
    
    // Simulate upload (in a real app, this would be an AJAX call)
    setTimeout(() => {
      const teacherClass = localStorage.getItem('teacherClass');
      const teacherSubject = localStorage.getItem('teacherSubject');
      
      if (!teacherClass || !teacherSubject) {
        showToast('Class/subject information missing', 'error');
        return;
      }
      
      try {
        // Add to materialsData (simulating database)
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          const newId = materialsData.length > 0 ? 
            Math.max(...materialsData.map(m => m.id)) + 1 : 1;
          
          materialsData.push({
            id: newId,
            name: `${chapter} - ${file.name}`,
            type: materialType.value,
            class: teacherClass,
            subject: teacherSubject,
            date: new Date().toISOString().split('T')[0],
            size: formatFileSize(file.size),
            downloads: 0
          });
        }
        
        // Reset form
        files = [];
        filePreview.innerHTML = '';
        chapterInput.value = '';
        fileInput.value = '';
        
        showToast('Files uploaded successfully!', 'success');
        
        // Reload materials list
        loadMaterials(teacherClass, teacherSubject);
        
        // Switch to manage tab
        switchTab('manageTab');
      } catch (error) {
        console.error('Upload error:', error);
        showToast('Error uploading files', 'error');
      } finally {
        // Update UI
        if (btnText) btnText.textContent = 'Upload Materials';
        if (spinner) spinner.classList.add('hidden');
        uploadBtn.disabled = false;
      }
    }, 1500);
  }
}

function formatFileSize(bytes) {
  if (typeof bytes !== 'number' || bytes < 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// Toast notification function
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  
  // Style the toast (add these styles to your CSS)
  toast.style.position = 'fixed';
  toast.style.bottom = '20px';
  toast.style.left = '50%';
  toast.style.transform = 'translateX(-50%)';
  toast.style.padding = '12px 24px';
  toast.style.background = type === 'success' ? '#10B981' : '#EF4444';
  toast.style.color = 'white';
  toast.style.borderRadius = '8px';
  toast.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
  toast.style.zIndex = '1000';
  toast.style.animation = 'fadeIn 0.3s ease-out';
  
  document.body.appendChild(toast);
  
  // Remove toast after 3 seconds
  setTimeout(() => {
    toast.style.animation = 'fadeOut 0.3s ease-out';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// Make sure to add these styles to your CSS:
/*
@keyframes fadeIn {
  from { opacity: 0; transform: translateX(-50%) translateY(20px); }
  to { opacity: 1; transform: translateX(-50%) translateY(0); }
}

@keyframes fadeOut {
  from { opacity: 1; transform: translateX(-50%) translateY(0); }
  to { opacity: 0; transform: translateX(-50%) translateY(20px); }
}

.toast {
  animation: fadeIn 0.3s ease-out;
}
*/
document.addEventListener('DOMContentLoaded', () => {
  const userRole = localStorage.getItem('userType');
  if (userRole !== 'teacher') {
    alert('Teacher access required');
    window.location.href = 'login.html';
  }
  
  // Rest of existing teacher.js code...
});